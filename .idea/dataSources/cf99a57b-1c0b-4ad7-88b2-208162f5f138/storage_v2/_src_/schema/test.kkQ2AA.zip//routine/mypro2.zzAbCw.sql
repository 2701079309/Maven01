create
    definer = root@localhost procedure mypro2(IN classid int, OUT v_sum int)
begin 
select count(*) into v_sum from class
where class_id=classid;
end;

