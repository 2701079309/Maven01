create
    definer = root@localhost procedure mypro(OUT student_id int)
begin
select count(*) into student_id from student;
end;

