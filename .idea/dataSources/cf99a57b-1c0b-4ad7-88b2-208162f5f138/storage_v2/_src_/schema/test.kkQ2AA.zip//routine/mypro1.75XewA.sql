create
    definer = root@localhost procedure mypro1()
begin
select *from class;
end;

